/**
 * It'd be nice to eventually replace this functionality with a real editor/renderer
 */
import * as React from 'react';
export declare function htmlEncode(str: string): string;
export declare function getReactLines(str: string | string[]): React.ReactElement<void>;
//# sourceMappingURL=encodingUtilities.d.ts.map