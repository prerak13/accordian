declare const styles: {};
export default styles;
//# sourceMappingURL=MobilePreviewCommon.module.scss.d.ts.map