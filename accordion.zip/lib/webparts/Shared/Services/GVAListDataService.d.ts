import { ServiceKey, ServiceScope } from '@microsoft/sp-core-library';
import { IGVAListService } from '../Model/IGVAListService';
export declare class GVAListDataService implements IGVAListService {
    static readonly serviceKey: ServiceKey<IGVAListService>;
    private _spHttpClient;
    private _pageContext;
    private _currentWebUrl;
    constructor(serviceScope: ServiceScope);
    getAllItems(listName: string): Promise<any>;
}
//# sourceMappingURL=GVAListDataService.d.ts.map