export interface IGVAListService {
    getAllItems(listName: string): Promise<Array<any>>;
}
//# sourceMappingURL=IGVAListService.d.ts.map