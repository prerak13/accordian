import * as React from 'react';
import { IAccordionProps } from './IAccordionProps';
import './Accordion.css';
import { IDocLibrary } from '../../Shared/Model/IGVAListsInterfaces';
export interface IAccordianState {
    listItems: IDocLibrary[];
}
export default class AccordionWP extends React.Component<IAccordionProps, IAccordianState> {
    constructor(p: IAccordionProps, s: IAccordianState);
    componentDidMount(): void;
    render(): React.ReactElement<IAccordionProps>;
}
//# sourceMappingURL=Accordion.d.ts.map