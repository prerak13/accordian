import { IGVAListService } from "../../Shared/Model/IGVAListService";

export interface IAccordionProps {
  description: string;
  listName:string;
  listService: IGVAListService;
  webUrl:string
}

