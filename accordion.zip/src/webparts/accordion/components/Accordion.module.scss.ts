/* tslint:disable */
require("./Accordion.module.css");
const styles = {
  accordion: 'accordion_95c0cc87',
  container: 'container_95c0cc87',
  row: 'row_95c0cc87',
  column: 'column_95c0cc87',
  'ms-Grid': 'ms-Grid_95c0cc87',
  title: 'title_95c0cc87',
  subTitle: 'subTitle_95c0cc87',
  description: 'description_95c0cc87',
  button: 'button_95c0cc87',
  label: 'label_95c0cc87'
};

export default styles;
/* tslint:enable */