declare interface IAccordionWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AccordionWebPartStrings' {
  const strings: IAccordionWebPartStrings;
  export = strings;
}
